package com.example.vudou.vidientu;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/**
 * Created by vudou on 8/3/2017.
 */

public class DemoReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {

    }


}
