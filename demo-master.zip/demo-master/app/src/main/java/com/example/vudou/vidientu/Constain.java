package com.example.vudou.vidientu;

/**
 * Created by vudou on 8/2/2017.
 */

public class Constain {
    public static String FINNISH_ACT = "finish_act";



}
